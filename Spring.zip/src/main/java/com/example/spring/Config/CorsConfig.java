package com.example.spring.Config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.filter.CorsFilter;

//设置允许跨域请求并且标注CorsConfig使用实体类
@Configuration
public class CorsConfig {
    @Bean  //产生一个Bean类 Spring Boot接手管理
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration(); //创建一个类对Cors进行各种配置
        config.addAllowedOrigin("*"); // 允许所有来源
        config.addAllowedMethod("*"); // 允许所有请求方法
        config.addAllowedHeader("*"); // 允许所有请求头

        org.springframework.web.cors.UrlBasedCorsConfigurationSource source = new org.springframework.web.cors.UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);

        return new CorsFilter(source);
    }
}
