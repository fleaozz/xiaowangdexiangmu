package com.example.spring.Pojo;


//处理数据
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table(name = "travel_16")
public class Travel_16 {
    @Id

    @Column(name = "travel_city",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelcity; //TEXT类型的列

    @Column(name = "travel_cite",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelcite; //TEXT类型的列

    @Column(name = "travel_cite_mark",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelcitemark; //TEXT类型的列
    @Column(name = "travel_food",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelfood; //TEXT类型的列

    @Column(name = "travel_food_mark",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelfoodmark; //TEXT类型的列



    public String getTravelcite() {return travelcite;}
    public void setTravelcite(String travelcite) {this.travelcite=travelcite;}
    public String getTravelcity() {return travelcity;}
    public void setTravelcity(String travelcity) {this.travelcity=travelcity;}
    public String getTravelcitemark() {return travelcitemark;}
    public void setTravelcitemark(String travelcitemark) {this.travelcitemark=travelcitemark;}
    public String getTravelfood() {return travelfood;}
    public void setTravelfodd(String travelfood) {this.travelfood=travelfood;}
    public String getTravelfoodmark() {return travelfoodmark;}
    public void setTravelfoodmark(String travelfoodmark) {this.travelfoodmark=travelfoodmark;}




}

