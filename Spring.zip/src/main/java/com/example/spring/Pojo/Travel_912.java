package com.example.spring.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Travel_912")
public class Travel_912 {
    @Id
    @Column(name = "travel_place",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelplace; //TEXT类型的列

    @Column(name = "travel_city",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelcity; //TEXT类型的列

    @Column(name = "travel_name",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelname; //TEXT类型的列

    @Column(name = "travel_total",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String traveltotal; //TEXT类型的列
    @Column(name = "travel_notes_url",columnDefinition = "TEXT") //MYSQL里的数据类型是TEXT
    private String travelnotesurl; //TEXT类型的列

    public String getTravelplace() {return travelplace;}
    public void setTravelplace(String travelplace) {this.travelplace=travelplace;}

    public String getTravelcity() {return travelcity;}
    public void setTravelcity(String travelcity) {this.travelcity=travelcity;}

    public String getTravelname() {return travelname;}
    public void setTravelname(String travelname) {this.travelname=travelname;}

    public String getTraveltotal() {return traveltotal;}
    public void setTraveltotal(String traveltotal) {this.traveltotal=traveltotal;}

    public String getTravelnotesurl() {return travelnotesurl;}
    public void setTravelnotesurl(String travelnotesurl) {this.travelnotesurl=travelnotesurl;}
}

