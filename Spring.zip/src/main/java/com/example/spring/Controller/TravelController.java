package com.example.spring.Controller;


import com.example.spring.Dao.*;  //导入Dao下的所有类和接口
import com.example.spring.Pojo.*; //导入Pojo下的所有类和接口

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/data")  //Mysql使用的数据库
public class TravelController {
    @Autowired //自动装配
    private Travel_16Dao travel_16Dao;

    @Autowired
    private Travel_518Dao travel_518Dao;
    @Autowired
    private Travel_520Dao travel_520Dao;
    @Autowired
    private Travel_525Dao travel_525Dao;
    @Autowired
    private Travel_528Dao travel_528Dao;
    @Autowired
    private Travel_530Dao travel_530Dao;
    @Autowired
    private Travel_531Dao travel_531Dao;


    @Autowired
    private Travel_601Dao travel_601Dao;
    @Autowired
    private Travel_602Dao travel_602Dao;
    @Autowired
    private Travel_603Dao travel_603Dao;
    @Autowired
    private Travel_604Dao travel_604Dao;
    @Autowired
    private Travel_605Dao travel_605Dao;
    @Autowired
    private Travel_606Dao travel_606Dao;
    @Autowired
    private Travel_607Dao travel_607Dao;
    @Autowired
    private Travel_608Dao travel_608Dao;
    @Autowired
    private Travel_609Dao travel_609Dao;
    @Autowired
    private Travel_610Dao travel_610Dao;
    @Autowired
    private Travel_611Dao travel_611Dao;
    @Autowired
    private Travel_612Dao travel_612Dao;
    @Autowired
    private Travel_613Dao travel_613Dao;
    @Autowired
    private Travel_614Dao travel_614Dao;
    @Autowired
    private Travel_615Dao travel_615Dao;
    @Autowired
    private Travel_616Dao travel_616Dao;
    @Autowired
    private Travel_618Dao travel_618Dao;
    @Autowired
    private Travel_619Dao travel_619Dao;
    @Autowired
    private Travel_620Dao travel_620Dao;
    @Autowired
    private Travel_621Dao travel_621Dao;
    @Autowired
    private Travel_622Dao travel_622Dao;
    @Autowired
    private Travel_623Dao travel_623Dao;
    @Autowired
    private Travel_624Dao travel_624Dao;
    @Autowired
    private Travel_625Dao travel_625Dao;
    @Autowired
    private Travel_626Dao travel_626Dao;
    @Autowired
    private Travel_627Dao travel_627Dao;
    @Autowired
    private Travel_628Dao travel_628Dao;
    @Autowired
    private Travel_629Dao travel_629Dao;
    @Autowired
    private Travel_630Dao travel_630Dao;


    @Autowired
    private Travel_701Dao travel_701Dao;
    @Autowired
    private Travel_702Dao travel_702Dao;
    @Autowired
    private Travel_703Dao travel_703Dao;
    @Autowired
    private Travel_704Dao travel_704Dao;
    @Autowired
    private Travel_705Dao travel_705Dao;
    @Autowired
    private Travel_706Dao travel_706Dao;
    @Autowired
    private Travel_707Dao travel_707Dao;
    @Autowired
    private Travel_708Dao travel_708Dao;
    @Autowired
    private Travel_709Dao travel_709Dao;
    @Autowired
    private Travel_710Dao travel_710Dao;
    @Autowired
    private Travel_711Dao travel_711Dao;
    @Autowired
    private Travel_712Dao travel_712Dao;
    @Autowired
    private Travel_713Dao travel_713Dao;
    @Autowired
    private Travel_714Dao travel_714Dao;
    @Autowired
    private Travel_715Dao travel_715Dao;
    @Autowired
    private Travel_725Dao travel_725Dao;
    @Autowired
    private Travel_726Dao travel_726Dao;
    @Autowired
    private Travel_727Dao travel_727Dao;
    @Autowired
    private Travel_728Dao travel_728Dao;
    @Autowired
    private Travel_729Dao travel_729Dao;
    @Autowired
    private Travel_730Dao travel_730Dao;
    @Autowired
    private Travel_731Dao travel_731Dao;



    @Autowired
    private Travel_801Dao travel_801Dao;
    @Autowired
    private Travel_802Dao travel_802Dao;
    @Autowired
    private Travel_803Dao travel_803Dao;
    @Autowired
    private Travel_804Dao travel_804Dao;
    @Autowired
    private Travel_805Dao travel_805Dao;
    @Autowired
    private Travel_806Dao travel_806Dao;
    @Autowired
    private Travel_807Dao travel_807Dao;
    @Autowired
    private Travel_808Dao travel_808Dao;
    @Autowired
    private Travel_809Dao travel_809Dao;
    @Autowired
    private Travel_810Dao travel_810Dao;
    @Autowired
    private Travel_811Dao travel_811Dao;
    @Autowired
    private Travel_812Dao travel_812Dao;
    @Autowired
    private Travel_813Dao travel_813Dao;
    @Autowired
    private Travel_814Dao travel_814Dao;
    @Autowired
    private Travel_815Dao travel_815Dao;
    @Autowired
    private Travel_816Dao travel_816Dao;
    @Autowired
    private Travel_817Dao travel_817Dao;
    @Autowired
    private Travel_818Dao travel_818Dao;
    @Autowired
    private Travel_819Dao travel_819Dao;
    @Autowired
    private Travel_820Dao travel_820Dao;
    @Autowired
    private Travel_821Dao travel_821Dao;
    @Autowired
    private Travel_822Dao travel_822Dao;
    @Autowired
    private Travel_823Dao travel_823Dao;
    @Autowired
    private Travel_824Dao travel_824Dao;
    @Autowired
    private Travel_825Dao travel_825Dao;
    @Autowired
    private Travel_826Dao travel_826Dao;
    @Autowired
    private Travel_827Dao travel_827Dao;
    @Autowired
    private Travel_828Dao travel_828Dao;
    @Autowired
    private Travel_829Dao travel_829Dao;
    @Autowired
    private Travel_830Dao travel_830Dao;
    @Autowired
    private Travel_901Dao travel_901Dao;
    @Autowired
    private Travel_902Dao travel_902Dao;
    @Autowired
    private Travel_903Dao travel_903Dao;
    @Autowired
    private Travel_904Dao travel_904Dao;
    @Autowired
    private Travel_905Dao travel_905Dao;
    @Autowired
    private Travel_906Dao travel_906Dao;
    @Autowired
    private Travel_907Dao travel_907Dao;
    @Autowired
    private Travel_910Dao travel_910Dao;
    @Autowired
    private Travel_911Dao travel_911Dao;
    @Autowired
    private Travel_912Dao travel_912Dao;
    @Autowired
    private Travel_913Dao travel_913Dao;
    @Autowired
    private Travel_914Dao travel_914Dao;
    @Autowired
    private Travel_915Dao travel_915Dao;


    @RequestMapping("/travel_16")//请求路径  //使用RequestMapping共享映射
    public List<Travel_16> getTravel_16() {
        return travel_16Dao.findAll();
    }



    @RequestMapping("/travel_518")//请求路径 //findAll方法返回Dao类所有数据
    public List<Travel_518> getTravel_518() {return travel_518Dao.findAll();}
    @RequestMapping("/travel_520")//请求路径
    public List<Travel_520> getTravel_520() {return travel_520Dao.findAll();}
    @RequestMapping("/travel_525")//请求路径
    public List<Travel_525> getTravel_525() {return travel_525Dao.findAll();}
    @RequestMapping("/travel_528")//请求路径
    public List<Travel_528> getTravel_528() {return travel_528Dao.findAll();}
    @RequestMapping("/travel_530")//请求路径
    public List<Travel_530> getTravel_530() {return travel_530Dao.findAll();}
    @RequestMapping("/travel_531")//请求路径
    public List<Travel_531> getTravel_531() {return travel_531Dao.findAll();}



    @RequestMapping("/travel_601")//请求路径
    public List<Travel_601> getTravel_601() {return travel_601Dao.findAll();}
    @RequestMapping("/travel_602")//请求路径
    public List<Travel_602> getTravel_602() {return travel_602Dao.findAll();}
    @RequestMapping("/travel_603")//请求路径
    public List<Travel_603> getTravel_603() {return travel_603Dao.findAll();}
    @RequestMapping("/travel_604")//请求路径
    public List<Travel_604> getTravel_604() {return travel_604Dao.findAll();}
    @RequestMapping("/travel_605")//请求路径
    public List<Travel_605> getTravel_605() {return travel_605Dao.findAll();}
    @RequestMapping("/travel_606")//请求路径
    public List<Travel_606> getTravel_606() {return travel_606Dao.findAll();}
    @RequestMapping("/travel_607")//请求路径
    public List<Travel_607> getTravel_607() {return travel_607Dao.findAll();}

    @RequestMapping("/travel_608")//请求路径
    public List<Travel_608> getTravel_608() {return travel_608Dao.findAll();}

    @RequestMapping("/travel_609")//请求路径
    public List<Travel_609> getTravel_609() {return travel_609Dao.findAll();}

    @RequestMapping("/travel_610")//请求路径
    public List<Travel_610> getTravel_610() {return travel_610Dao.findAll();}

    @RequestMapping("/travel_611")//请求路径
    public List<Travel_611> getTravel_611() {return travel_611Dao.findAll();}
    @RequestMapping("/travel_612")//请求路径
    public List<Travel_612> getTravel_612() {return travel_612Dao.findAll();}
    @RequestMapping("/travel_613")//请求路径
    public List<Travel_613> getTravel_613() {return travel_613Dao.findAll();}
    @RequestMapping("/travel_614")//请求路径
    public List<Travel_614> getTravel_614() {return travel_614Dao.findAll();}
    @RequestMapping("/travel_615")//请求路径
    public List<Travel_615> getTravel_615() {return travel_615Dao.findAll();}
    @RequestMapping("/travel_616")//请求路径
    public List<Travel_616> getTravel_616() {return travel_616Dao.findAll();}
    @RequestMapping("/travel_618")//请求路径
    public List<Travel_618> getTravel_618() {return travel_618Dao.findAll();}
    @RequestMapping("/travel_619")//请求路径
    public List<Travel_619> getTravel_619() {return travel_619Dao.findAll();}
    @RequestMapping("/travel_620")//请求路径
    public List<Travel_620> getTravel_620() {return travel_620Dao.findAll();}
    @RequestMapping("/travel_621")//请求路径
    public List<Travel_621> getTravel_621() {return travel_621Dao.findAll();}
    @RequestMapping("/travel_622")//请求路径
    public List<Travel_622> getTravel_622() {return travel_622Dao.findAll();}
    @RequestMapping("/travel_623")//请求路径
    public List<Travel_623> getTravel_623() {return travel_623Dao.findAll();}
    @RequestMapping("/travel_624")//请求路径
    public List<Travel_624> getTravel_624() {return travel_624Dao.findAll();}
    @RequestMapping("/travel_625")//请求路径
    public List<Travel_625> getTravel_625() {return travel_625Dao.findAll();}
    @RequestMapping("/travel_626")//请求路径
    public List<Travel_626> getTravel_626() {return travel_626Dao.findAll();}
    @RequestMapping("/travel_627")//请求路径
    public List<Travel_627> getTravel_627() {return travel_627Dao.findAll();}
    @RequestMapping("/travel_628")//请求路径
    public List<Travel_628> getTravel_628() {return travel_628Dao.findAll();}
    @RequestMapping("/travel_629")//请求路径
    public List<Travel_629> getTravel_629() {return travel_629Dao.findAll();}
    @RequestMapping("/travel_630")//请求路径
    public List<Travel_630> getTravel_630() {return travel_630Dao.findAll();}




    @RequestMapping("/travel_701")//请求路径
    public List<Travel_701> getTravel_701() {return travel_701Dao.findAll();}
    @RequestMapping("/travel_702")//请求路径
    public List<Travel_702> getTravel_702() {return travel_702Dao.findAll();}
    @RequestMapping("/travel_703")//请求路径
    public List<Travel_703> getTravel_703() {return travel_703Dao.findAll();}
    @RequestMapping("/travel_704")//请求路径
    public List<Travel_704> getTravel_704() {return travel_704Dao.findAll();}
    @RequestMapping("/travel_705")//请求路径
    public List<Travel_705> getTravel_705() {return travel_705Dao.findAll();}
    @RequestMapping("/travel_706")//请求路径
    public List<Travel_706> getTravel_706() {return travel_706Dao.findAll();}
    @RequestMapping("/travel_707")//请求路径
    public List<Travel_707> getTravel_707() {return travel_707Dao.findAll();}
    @RequestMapping("/travel_708")//请求路径
    public List<Travel_708> getTravel_708() {return travel_708Dao.findAll();}
    @RequestMapping("/travel_709")//请求路径
    public List<Travel_709> getTravel_709() {return travel_709Dao.findAll();}
    @RequestMapping("/travel_710")//请求路径
    public List<Travel_710> getTravel_710() {return travel_710Dao.findAll();}
    @RequestMapping("/travel_711")//请求路径
    public List<Travel_711> getTravel_711() {return travel_711Dao.findAll();}
    @RequestMapping("/travel_712")//请求路径
    public List<Travel_712> getTravel_712() {return travel_712Dao.findAll();}
    @RequestMapping("/travel_713")//请求路径
    public List<Travel_713> getTravel_713() {return travel_713Dao.findAll();}
    @RequestMapping("/travel_714")//请求路径
    public List<Travel_714> getTravel_714() {return travel_714Dao.findAll();}
    @RequestMapping("/travel_715")//请求路径
    public List<Travel_715> getTravel_715() {return travel_715Dao.findAll();}
    @RequestMapping("/travel_725")//请求路径
    public List<Travel_725> getTravel_725() {return travel_725Dao.findAll();}
    @RequestMapping("/travel_726")//请求路径
    public List<Travel_726> getTravel_726() {return travel_726Dao.findAll();}
    @RequestMapping("/travel_727")//请求路径
    public List<Travel_727> getTravel_727() {return travel_727Dao.findAll();}
    @RequestMapping("/travel_728")//请求路径
    public List<Travel_728> getTravel_728() {return travel_728Dao.findAll();}
    @RequestMapping("/travel_729")//请求路径
    public List<Travel_729> getTravel_729() {return travel_729Dao.findAll();}
    @RequestMapping("/travel_730")//请求路径
    public List<Travel_730> getTravel_730() {return travel_730Dao.findAll();}
    @RequestMapping("/travel_731")//请求路径
    public List<Travel_731> getTravel_731() {return travel_731Dao.findAll();}




    @RequestMapping("/travel_801")//请求路径
    public List<Travel_801> getTravel_801() {return travel_801Dao.findAll();}
    @RequestMapping("/travel_802")//请求路径
    public List<Travel_802> getTravel_802() {return travel_802Dao.findAll();}
    @RequestMapping("/travel_803")//请求路径
    public List<Travel_803> getTravel_803() {return travel_803Dao.findAll();}
    @RequestMapping("/travel_804")//请求路径
    public List<Travel_804> getTravel_804() {return travel_804Dao.findAll();}
    @RequestMapping("/travel_805")//请求路径
    public List<Travel_805> getTravel_805() {return travel_805Dao.findAll();}
    @RequestMapping("/travel_806")//请求路径
    public List<Travel_806> getTravel_806() {return travel_806Dao.findAll();}
    @RequestMapping("/travel_807")//请求路径
    public List<Travel_807> getTravel_807() {return travel_807Dao.findAll();}
    @RequestMapping("/travel_808")//请求路径
    public List<Travel_808> getTravel_808() {return travel_808Dao.findAll();}
    @RequestMapping("/travel_809")//请求路径
    public List<Travel_809> getTravel_809() {return travel_809Dao.findAll();}
    @RequestMapping("/travel_810")//请求路径
    public List<Travel_810> getTravel_810() {return travel_810Dao.findAll();}
    @RequestMapping("/travel_811")//请求路径
    public List<Travel_811> getTravel_811() {return travel_811Dao.findAll();}
    @RequestMapping("/travel_812")//请求路径
    public List<Travel_812> getTravel_812() {return travel_812Dao.findAll();}
    @RequestMapping("/travel_813")//请求路径
    public List<Travel_813> getTravel_813() {return travel_813Dao.findAll();}
    @RequestMapping("/travel_814")//请求路径
    public List<Travel_814> getTravel_814() {return travel_814Dao.findAll();}
    @RequestMapping("/travel_815")//请求路径
    public List<Travel_815> getTravel_815() {return travel_815Dao.findAll();}
    @RequestMapping("/travel_816")//请求路径
    public List<Travel_816> getTravel_816() {return travel_816Dao.findAll();}
    @RequestMapping("/travel_817")//请求路径
    public List<Travel_817> getTravel_817() {return travel_817Dao.findAll();}
    @RequestMapping("/travel_818")//请求路径
    public List<Travel_818> getTravel_818() {return travel_818Dao.findAll();}
    @RequestMapping("/travel_819")//请求路径
    public List<Travel_819> getTravel_819() {return travel_819Dao.findAll();}
    @RequestMapping("/travel_820")//请求路径
    public List<Travel_820> getTravel_820() {return travel_820Dao.findAll();}
    @RequestMapping("/travel_821")//请求路径
    public List<Travel_821> getTravel_821() {return travel_821Dao.findAll();}
    @RequestMapping("/travel_822")//请求路径
    public List<Travel_822> getTravel_822() {return travel_822Dao.findAll();}
    @RequestMapping("/travel_823")//请求路径
    public List<Travel_823> getTravel_823() {return travel_823Dao.findAll();}
    @RequestMapping("/travel_824")//请求路径
    public List<Travel_824> getTravel_824() {return travel_824Dao.findAll();}
    @RequestMapping("/travel_825")//请求路径
    public List<Travel_825> getTravel_825() {return travel_825Dao.findAll();}
    @RequestMapping("/travel_826")//请求路径
    public List<Travel_826> getTravel_826() {return travel_826Dao.findAll();}
    @RequestMapping("/travel_827")//请求路径
    public List<Travel_827> getTravel_827() {return travel_827Dao.findAll();}
    @RequestMapping("/travel_828")//请求路径
    public List<Travel_828> getTravel_828() {return travel_828Dao.findAll();}
    @RequestMapping("/travel_829")//请求路径
    public List<Travel_829> getTravel_829() {return travel_829Dao.findAll();}
    @RequestMapping("/travel_830")//请求路径
    public List<Travel_830> getTravel_830() {return travel_830Dao.findAll();}

    @RequestMapping("/travel_901")//请求路径
    public List<Travel_901> getTravel_901() {return travel_901Dao.findAll();}
    @RequestMapping("/travel_902")//请求路径
    public List<Travel_902> getTravel_902() {return travel_902Dao.findAll();}
    @RequestMapping("/travel_903")//请求路径
    public List<Travel_903> getTravel_903() {return travel_903Dao.findAll();}
    @RequestMapping("/travel_904")//请求路径
    public List<Travel_904> getTravel_904() {return travel_904Dao.findAll();}
    @RequestMapping("/travel_905")//请求路径
    public List<Travel_905> getTravel_905() {return travel_905Dao.findAll();}
    @RequestMapping("/travel_906")//请求路径
    public List<Travel_906> getTravel_906() {return travel_906Dao.findAll();}
    @RequestMapping("/travel_907")//请求路径
    public List<Travel_907> getTravel_907() {return travel_907Dao.findAll();}
    @RequestMapping("/travel_910")//请求路径
    public List<Travel_910> getTravel_910() {return travel_910Dao.findAll();}

    @RequestMapping("/travel_911")//请求路径
    public List<Travel_911> getTravel_911() {return travel_911Dao.findAll();}

    @RequestMapping("/travel_912")//请求路径
    public List<Travel_912> getTravel_912() {return travel_912Dao.findAll();}
    @RequestMapping("/travel_913")//请求路径
    public List<Travel_913> getTravel_913() {return travel_913Dao.findAll();}
    @RequestMapping("/travel_914")//请求路径
    public List<Travel_914> getTravel_914() {return travel_914Dao.findAll();}
    @RequestMapping("/travel_915")//请求路径
    public List<Travel_915> getTravel_915() {return travel_915Dao.findAll();}
}
