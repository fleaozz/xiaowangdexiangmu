package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_812;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_812Dao extends JpaRepository<Travel_812, String>{

}
