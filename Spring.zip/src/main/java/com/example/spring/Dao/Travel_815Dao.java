package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_815;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_815Dao extends JpaRepository<Travel_815, String>{

}
