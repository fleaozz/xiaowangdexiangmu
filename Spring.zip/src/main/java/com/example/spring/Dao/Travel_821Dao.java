package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_821;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_821Dao extends JpaRepository<Travel_821, String>{

}
