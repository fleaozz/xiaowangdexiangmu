package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_819;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_819Dao extends JpaRepository<Travel_819, String>{

}
