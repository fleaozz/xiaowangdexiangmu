package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_604;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_604Dao extends JpaRepository<Travel_604, String>{

}
