package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_621;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_621Dao extends JpaRepository<Travel_621, String>{

}
