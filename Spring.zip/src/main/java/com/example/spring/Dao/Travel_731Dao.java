package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_731;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_731Dao extends JpaRepository<Travel_731, String>{

}
