package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_628;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_628Dao extends JpaRepository<Travel_628, String>{

}
