package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_715;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_715Dao extends JpaRepository<Travel_715, String>{

}
