package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_619;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_619Dao extends JpaRepository<Travel_619, String>{

}
