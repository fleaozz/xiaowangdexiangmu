package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_817;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_817Dao extends JpaRepository<Travel_817, String>{

}
