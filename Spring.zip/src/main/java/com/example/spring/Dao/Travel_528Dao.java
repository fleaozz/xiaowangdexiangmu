package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_528;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_528Dao extends JpaRepository<Travel_528, String>{

}
