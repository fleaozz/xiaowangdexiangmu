package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_525;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_525Dao extends JpaRepository<Travel_525, String>{

}
