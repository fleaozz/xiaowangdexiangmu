package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_904;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_904Dao extends JpaRepository<Travel_904, String>{

}
