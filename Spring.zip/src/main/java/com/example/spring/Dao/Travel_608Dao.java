package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_608;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_608Dao extends JpaRepository<Travel_608, String>{

}
