package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_829;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_829Dao extends JpaRepository<Travel_829, String>{

}
