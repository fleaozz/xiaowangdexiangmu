package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_805;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_805Dao extends JpaRepository<Travel_805, String>{

}
