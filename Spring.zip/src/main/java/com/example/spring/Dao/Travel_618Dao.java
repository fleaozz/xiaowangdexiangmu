package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_618;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_618Dao extends JpaRepository<Travel_618, String>{

}
