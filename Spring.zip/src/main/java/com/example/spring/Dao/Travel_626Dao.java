package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_626;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_626Dao extends JpaRepository<Travel_626, String>{

}
