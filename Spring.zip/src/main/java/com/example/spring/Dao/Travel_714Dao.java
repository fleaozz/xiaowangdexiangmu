package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_714;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_714Dao extends JpaRepository<Travel_714, String>{

}
