package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_624;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_624Dao extends JpaRepository<Travel_624, String>{

}
