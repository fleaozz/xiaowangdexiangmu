package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_807;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_807Dao extends JpaRepository<Travel_807, String>{

}
