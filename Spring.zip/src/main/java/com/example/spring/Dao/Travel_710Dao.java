package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_710;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_710Dao extends JpaRepository<Travel_710, String>{

}
