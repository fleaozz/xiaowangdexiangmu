package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_703;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_703Dao extends JpaRepository<Travel_703, String>{

}
