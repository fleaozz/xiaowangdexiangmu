package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_704;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_704Dao extends JpaRepository<Travel_704, String>{

}
