package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_809;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_809Dao extends JpaRepository<Travel_809, String>{

}
