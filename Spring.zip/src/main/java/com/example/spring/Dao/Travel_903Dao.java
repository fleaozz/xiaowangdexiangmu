package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_903;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_903Dao extends JpaRepository<Travel_903, String>{

}
