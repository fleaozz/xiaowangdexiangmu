package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_801;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_801Dao extends JpaRepository<Travel_801, String>{

}
