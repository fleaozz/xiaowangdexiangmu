package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_725;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_725Dao extends JpaRepository<Travel_725, String>{

}
