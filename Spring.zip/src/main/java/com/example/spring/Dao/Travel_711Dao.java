package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_711;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_711Dao extends JpaRepository<Travel_711, String>{

}
