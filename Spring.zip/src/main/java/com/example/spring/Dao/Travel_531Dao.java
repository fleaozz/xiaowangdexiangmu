package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_531;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_531Dao extends JpaRepository<Travel_531, String>{

}
