package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_625;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_625Dao extends JpaRepository<Travel_625, String>{

}
