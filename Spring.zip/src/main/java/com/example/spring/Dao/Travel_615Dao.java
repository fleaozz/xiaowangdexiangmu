package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_615;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_615Dao extends JpaRepository<Travel_615, String>{

}
