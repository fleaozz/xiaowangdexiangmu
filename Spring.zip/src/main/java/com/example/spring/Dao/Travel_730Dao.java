package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_730;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_730Dao extends JpaRepository<Travel_730, String>{

}
