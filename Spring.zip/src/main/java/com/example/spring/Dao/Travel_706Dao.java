package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_706;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_706Dao extends JpaRepository<Travel_706, String>{

}
