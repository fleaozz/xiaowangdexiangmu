package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_607;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_607Dao extends JpaRepository<Travel_607, String>{

}
