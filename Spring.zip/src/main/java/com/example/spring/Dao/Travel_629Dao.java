package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_629;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_629Dao extends JpaRepository<Travel_629, String>{

}
