package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_827;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_827Dao extends JpaRepository<Travel_827, String>{

}
