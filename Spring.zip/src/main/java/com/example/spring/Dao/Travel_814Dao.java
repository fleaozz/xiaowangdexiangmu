package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_814;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_814Dao extends JpaRepository<Travel_814, String>{

}
