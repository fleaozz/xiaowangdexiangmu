package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_727;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_727Dao extends JpaRepository<Travel_727, String>{

}
