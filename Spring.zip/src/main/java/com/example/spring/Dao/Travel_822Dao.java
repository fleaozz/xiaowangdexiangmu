package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_822;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_822Dao extends JpaRepository<Travel_822, String>{

}
