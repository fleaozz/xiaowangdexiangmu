package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_705;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_705Dao extends JpaRepository<Travel_705, String>{

}
