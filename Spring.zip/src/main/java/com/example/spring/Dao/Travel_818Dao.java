package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_818;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_818Dao extends JpaRepository<Travel_818, String>{

}
