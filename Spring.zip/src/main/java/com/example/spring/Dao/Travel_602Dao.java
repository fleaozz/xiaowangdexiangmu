package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_602;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_602Dao extends JpaRepository<Travel_602, String>{

}
