package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_901;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_901Dao extends JpaRepository<Travel_901, String>{

}
