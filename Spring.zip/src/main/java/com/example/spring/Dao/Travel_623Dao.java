package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_623;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_623Dao extends JpaRepository<Travel_623, String>{

}
