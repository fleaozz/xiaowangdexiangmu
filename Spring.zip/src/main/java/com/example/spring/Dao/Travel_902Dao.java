package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_902;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_902Dao extends JpaRepository<Travel_902, String>{

}
