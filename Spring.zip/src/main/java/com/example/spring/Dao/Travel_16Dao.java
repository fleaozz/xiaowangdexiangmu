package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_16;
import org.springframework.data.jpa.repository.JpaRepository;

// Dao类 操作数据库
// JpaRepository支持接口规范方法名查询
public interface Travel_16Dao extends JpaRepository<Travel_16, String>{

}
