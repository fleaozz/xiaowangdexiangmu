package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_816;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_816Dao extends JpaRepository<Travel_816, String>{

}
