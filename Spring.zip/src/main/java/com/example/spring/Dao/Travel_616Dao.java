package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_616;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_616Dao extends JpaRepository<Travel_616, String>{

}
