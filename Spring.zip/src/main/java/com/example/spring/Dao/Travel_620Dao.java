package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_620;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_620Dao extends JpaRepository<Travel_620, String>{

}
