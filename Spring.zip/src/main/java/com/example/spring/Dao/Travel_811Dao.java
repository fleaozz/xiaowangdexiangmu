package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_811;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_811Dao extends JpaRepository<Travel_811, String>{

}
