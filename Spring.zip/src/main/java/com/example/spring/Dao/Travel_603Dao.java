package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_603;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_603Dao extends JpaRepository<Travel_603, String>{

}
