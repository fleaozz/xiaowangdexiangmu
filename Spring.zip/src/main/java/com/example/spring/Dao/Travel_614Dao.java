package com.example.spring.Dao;

import com.example.spring.Pojo.Travel_614;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Travel_614Dao extends JpaRepository<Travel_614, String>{

}
